<?php

return [
    'name' => 'Otp'
];
